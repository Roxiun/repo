function openSettings() {
    api.apps.launchApplication("com.apple.Preferences");
}